
$(function(){
    $('.style').on('click', function(){
        $('body').toggleClass('black');
    });
});